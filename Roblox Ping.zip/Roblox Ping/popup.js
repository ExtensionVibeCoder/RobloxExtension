function applyPing(ms) {
    const col     = ms < 80 ? "#00e676" : ms < 150 ? "#ffb300" : "#ff4d4d";
    const quality = ms < 80 ? "Excellent" : ms < 120 ? "Good" : ms < 180 ? "Fair" : "Poor";
    const signal  = ms < 80 ? "Strong" : ms < 150 ? "Moderate" : "Weak";
    const dc      = ms < 50 ? "US-East" : ms < 90 ? "US-West" : ms < 130 ? "Europe" : ms < 180 ? "Asia" : "AU / SA";
    const pct     = Math.min((ms / 280) * 100, 100);

    document.getElementById("bigNum").textContent   = ms === -1 ? "?" : ms;
    document.getElementById("bigUnit").textContent  = ms === -1 ? "" : "ms";
    document.getElementById("bigNum").style.color   = ms === -1 ? "#3a4068" : "#f0f2ff";
    document.getElementById("quality").textContent  = ms === -1 ? "Timeout" : quality;
    document.getElementById("quality").style.color  = col;
    document.getElementById("region").textContent   = ms === -1 ? "no response" : dc;
    document.getElementById("dc").textContent       = ms === -1 ? "--" : dc;
    document.getElementById("dc").style.color       = col;
    document.getElementById("signal").textContent   = ms === -1 ? "--" : signal;
    document.getElementById("signal").style.color   = col;
    document.getElementById("bar").style.width      = `${pct}%`;
    document.getElementById("bar").style.background = col;
}

function refresh() {
    document.getElementById("bigNum").textContent  = "--";
    document.getElementById("bigUnit").textContent = "";
    chrome.runtime.sendMessage({ type: "PING" }, (res) => {
        if (res) applyPing(res.ms);
    });
}

chrome.runtime.sendMessage({ type: "PING" }, (res) => {
    if (res) applyPing(res.ms);
});