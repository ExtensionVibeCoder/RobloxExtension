(function () {
    chrome.runtime.sendMessage({ type: "PAGE_LOAD" });

    _injectFont();
    _injectStyles();
    _injectWidget();
    _observeServers();

    function _injectFont() {
        if (document.getElementById("_ph_font")) return;
        const l = document.createElement("link");
        l.id   = "_ph_font";
        l.rel  = "stylesheet";
        l.href = "https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Inter:wght@400;500;600&display=swap";
        document.head.appendChild(l);
    }

    function _injectStyles() {
        if (document.getElementById("_ph_css")) return;
        const s = document.createElement("style");
        s.id = "_ph_css";
        s.textContent = `
            #_ph_widget {
                position: fixed;
                bottom: 20px; right: 20px;
                z-index: 99999;
                width: 200px;
                background: #07080f;
                border: 1px solid #13162a;
                border-radius: 14px;
                overflow: hidden;
                box-shadow:
                    0 0 0 1px #ffffff05,
                    0 20px 60px rgba(0,0,0,.7),
                    0 0 30px #00d8ff08;
                font-family: 'Inter', sans-serif;
                -webkit-font-smoothing: antialiased;
            }
            ._ph_wtop {
                display: flex; align-items: center; justify-content: space-between;
                padding: 10px 12px;
                border-bottom: 1px solid #0d0f1c;
            }
            ._ph_wlogo {
                display: flex; align-items: center; gap: 6px;
                font-family: 'Syne', sans-serif;
                font-size: 11px; font-weight: 700;
                color: #dde0f0;
            }
            ._ph_wlogo_dot {
                width: 6px; height: 6px; border-radius: 50%;
                background: #00e676;
                box-shadow: 0 0 6px #00e676;
            }
            ._ph_wlive {
                font-size: 9px; font-weight: 600;
                color: #1e2340;
            }
            ._ph_wbig {
                padding: 14px 14px 10px;
                border-bottom: 1px solid #0d0f1c;
                position: relative; overflow: hidden;
            }
            ._ph_wbig::before {
                content: '';
                position: absolute; top: -30px; left: -10px;
                width: 120px; height: 100px;
                background: radial-gradient(ellipse, #00d8ff0a, transparent 70%);
                pointer-events: none;
            }
            ._ph_wnum {
                font-family: 'Syne', sans-serif;
                font-size: 44px; font-weight: 800;
                line-height: 1; letter-spacing: -0.04em;
                color: #f0f2ff;
                display: inline;
            }
            ._ph_wunit {
                font-family: 'Syne', sans-serif;
                font-size: 15px; font-weight: 700;
                color: #00d8ff;
                vertical-align: text-bottom;
                margin-left: 2px;
            }
            ._ph_wqual {
                font-family: 'Syne', sans-serif;
                font-size: 11px; font-weight: 700;
                margin-top: 4px;
            }
            ._ph_wbar {
                height: 2px; background: #0d0f1c;
                margin: 0;
            }
            ._ph_wbar_fill {
                height: 100%; border-radius: 1px;
                transition: width .5s, background .3s;
            }
            ._ph_wrows { padding: 2px 0; }
            ._ph_wrow {
                display: flex; align-items: center; justify-content: space-between;
                padding: 7px 14px;
                border-bottom: 1px solid #080910;
            }
            ._ph_wrow:last-child { border-bottom: none; }
            ._ph_wlbl { font-size: 10px; color: #252b4a; }
            ._ph_wval {
                font-family: 'Syne', sans-serif;
                font-size: 11px; font-weight: 700;
                color: #dde0f0;
            }

            /* SERVER CARD BADGES */
            .ph-badge {
                display: inline-flex; align-items: center; gap: 5px;
                padding: 3px 9px;
                border-radius: 5px;
                font-family: 'Syne', sans-serif;
                font-size: 11px; font-weight: 700;
                letter-spacing: 0.01em;
                vertical-align: middle;
                white-space: nowrap;
                transition: all .2s;
            }
            .ph-dot {
                width: 5px; height: 5px; border-radius: 50%; flex-shrink: 0;
            }
            .ph-g { background:#00e67610; color:#00e676; border:1px solid #00e67628; }
            .ph-g .ph-dot { background:#00e676; box-shadow:0 0 5px #00e676; }
            .ph-a { background:#ffb30010; color:#ffb300; border:1px solid #ffb30028; }
            .ph-a .ph-dot { background:#ffb300; box-shadow:0 0 5px #ffb300; }
            .ph-r { background:#ff4d4d10; color:#ff4d4d; border:1px solid #ff4d4d28; }
            .ph-r .ph-dot { background:#ff4d4d; box-shadow:0 0 5px #ff4d4d; }
        `;
        document.head.appendChild(s);
    }

    function _injectWidget() {
        if (document.getElementById("_ph_widget")) return;

        const w = document.createElement("div");
        w.id = "_ph_widget";
        w.innerHTML = `
            <div class="_ph_wtop">
                <div class="_ph_wlogo">
                    <div class="_ph_wlogo_dot" id="_ph_ldot"></div>
                    Ping Helper
                </div>
                <div class="_ph_wlive">LIVE</div>
            </div>
            <div class="_ph_wbig">
                <span class="_ph_wnum" id="_ph_wnum">--</span><span class="_ph_wunit" id="_ph_wunit"></span>
                <div class="_ph_wqual" id="_ph_wqual" style="color:#252b4a">detecting...</div>
            </div>
            <div class="_ph_wbar"><div class="_ph_wbar_fill" id="_ph_wbar" style="width:0%;background:#00e676"></div></div>
            <div class="_ph_wrows">
                <div class="_ph_wrow">
                    <span class="_ph_wlbl">Region</span>
                    <span class="_ph_wval" id="_ph_wreg" style="color:#252b4a">--</span>
                </div>
                <div class="_ph_wrow">
                    <span class="_ph_wlbl">Signal</span>
                    <span class="_ph_wval" id="_ph_wsig" style="color:#252b4a">--</span>
                </div>
            </div>
        `;
        document.body.appendChild(w);

        _tickWidget();
        setInterval(_tickWidget, 5000);
    }

    function _tickWidget() {
        chrome.runtime.sendMessage({ type: "PING" }, (res) => {
            if (!res) return;
            const ms  = res.ms;
            const col = ms < 80 ? "#00e676" : ms < 150 ? "#ffb300" : "#ff4d4d";
            const q   = ms < 80 ? "Excellent" : ms < 120 ? "Good" : ms < 180 ? "Fair" : "Poor";
            const sig = ms < 80 ? "Strong" : ms < 150 ? "Moderate" : "Weak";
            const pct = Math.min((ms / 280) * 100, 100);

            const $ = id => document.getElementById(id);
            $("_ph_wnum").textContent   = ms === -1 ? "?" : ms;
            $("_ph_wunit").textContent  = ms === -1 ? "" : "ms";
            $("_ph_wqual").textContent  = ms === -1 ? "No response" : q;
            $("_ph_wqual").style.color  = col;
            $("_ph_wreg").textContent   = res.region;
            $("_ph_wreg").style.color   = col;
            $("_ph_wsig").textContent   = ms === -1 ? "--" : sig;
            $("_ph_wsig").style.color   = col;
            $("_ph_wbar").style.width      = `${pct}%`;
            $("_ph_wbar").style.background = col;
            $("_ph_ldot").style.background = col;
            $("_ph_ldot").style.boxShadow  = `0 0 6px ${col}`;
        });
    }

    function _observeServers() {
        new MutationObserver(() => {
            clearTimeout(window._phT);
            window._phT = setTimeout(_scanCards, 150);
        }).observe(document.body, { childList: true, subtree: true });
        _scanCards();
        setTimeout(_scanCards, 1500);
        setTimeout(_scanCards, 4000);
    }

    function _scanCards() {
        document.querySelectorAll([
            "li.rbx-game-server-item",
            "[class*='server-item-container']",
            "[class*='ServerCard']",
            "[class*='server-card']"
        ].join(",")).forEach(card => {
            if (card.dataset.phd) return;
            card.dataset.phd = "1";
            _addBadge(card);
        });

        document.querySelectorAll("ul li").forEach(el => {
            if (el.dataset.phd) return;
            if (!/\d+ of \d+ people max/i.test(el.innerText)) return;
            if (!el.querySelector("button, [class*='join'], [class*='btn']")) return;
            el.dataset.phd = "1";
            _addBadge(el);
        });
    }

    function _addBadge(card) {
        if (card.querySelector(".ph-badge")) return;

        const existing = card.innerText.match(/Ping\s+(\d+)\s*ms/i);
        const ms = existing ? parseInt(existing[1]) : null;

        const badge = document.createElement("span");
        badge.className = "ph-badge";
        badge.innerHTML = `<span class="ph-dot"></span><span class="ph-val"></span>`;

        if (ms !== null) {
            _styleBadge(badge, ms);
        } else {
            badge.querySelector(".ph-val").textContent = "…";
            badge.classList.add("ph-a");
            setTimeout(() => {
                chrome.runtime.sendMessage({ type: "PING" }, (res) => {
                    if (!res) return;
                    badge.className = "ph-badge";
                    badge.innerHTML = `<span class="ph-dot"></span><span class="ph-val"></span>`;
                    _styleBadge(badge, res.ms);
                });
            }, Math.random() * 600);
        }

        const countEl = [...card.querySelectorAll("*")]
            .find(el => el.children.length === 0 && /\d+ of \d+ people max/i.test(el.textContent));

        if (countEl) {
            countEl.style.cssText += "display:inline-flex;align-items:center;gap:8px;";
            countEl.querySelectorAll(".ph-badge").forEach(b => b.remove());
            countEl.appendChild(badge);
        } else {
            const join = card.querySelector("button, [class*='btn-primary'], [class*='join']");
            if (join) join.parentElement.insertBefore(badge, join);
            else card.appendChild(badge);
        }
    }

    function _styleBadge(badge, ms) {
        const cls = ms < 80 ? "ph-g" : ms < 150 ? "ph-a" : "ph-r";
        badge.classList.add(cls);
        badge.querySelector(".ph-val").textContent = ms === -1 ? "timeout" : `${ms}ms`;
    }

})();